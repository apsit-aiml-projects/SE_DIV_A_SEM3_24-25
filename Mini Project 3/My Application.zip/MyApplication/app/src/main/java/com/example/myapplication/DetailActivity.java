package com.example.myapplication;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.TextView;
import androidx.appcompat.app.AppCompatActivity;
import androidx.constraintlayout.widget.ConstraintLayout;
import android.widget.ScrollView;
import android.widget.Button;
import android.widget.Space;

public class DetailActivity extends MainActivity implements View.OnClickListener {

    private Intent intent;
    private Button Burns, Poisoning, CPR, Asthma, Bleeding, sprain_1,  sun_stroke, diabetic_emg, head_injury, Choking, nose_bleeding, Allergic, Snake_Bite, bee_sting, migraine, electric_shock, fungal_infection, food_poisoning, hypothermia, panic_attack;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_detail);

        Burns = findViewById(R.id.Burns);
        Poisoning = findViewById(R.id.Poisoning);
        CPR = findViewById(R.id.cpr_1);
        Asthma = findViewById(R.id.Asthma);
        Bleeding = findViewById(R.id.Bleeding);
        sprain_1 = findViewById(R.id.sprain_1);
        sun_stroke = findViewById(R.id.sun_stroke);
        diabetic_emg = findViewById(R.id.diabetic_emg);
        head_injury = findViewById(R.id.head_injury);
        Choking = findViewById(R.id.choking_1);
        nose_bleeding = findViewById(R.id.nose_bleeding);
        Allergic = findViewById(R.id.allergic_1);
        Snake_Bite = findViewById(R.id.snakebite);
        bee_sting = findViewById(R.id.bee_sting);
        migraine = findViewById(R.id.migraine);
        electric_shock = findViewById(R.id.electric_shock);
        fungal_infection = findViewById(R.id.fungal_infection);
        food_poisoning = findViewById(R.id.Food_poisoning);
        hypothermia = findViewById(R.id.hypothermia);
        panic_attack = findViewById(R.id.panic_attack);

        Burns.setOnClickListener(this);
        Poisoning.setOnClickListener(this);
        CPR.setOnClickListener(this);
        Bleeding.setOnClickListener(this);
        sprain_1.setOnClickListener(this);
        Asthma.setOnClickListener(this);
        sun_stroke.setOnClickListener(this);
        diabetic_emg.setOnClickListener(this);
        head_injury.setOnClickListener(this);
        Choking.setOnClickListener(this);
        nose_bleeding.setOnClickListener(this);
        Allergic.setOnClickListener(this);
        Snake_Bite.setOnClickListener(this);
        bee_sting.setOnClickListener(this);
        migraine.setOnClickListener(this);
        electric_shock.setOnClickListener(this);
        fungal_infection.setOnClickListener(this);
        food_poisoning.setOnClickListener(this);
        hypothermia.setOnClickListener(this);
        panic_attack.setOnClickListener(this);
    }

    @Override
    public void onClick(View v) {

        if (v.getId() == R.id.Burns) {
            intent = new Intent(DetailActivity.this, MainDetails.class);
            intent.putExtra("name", "Burns");
            startActivity(intent);

        }

        if (v.getId() == R.id.allergic_1) {
            intent = new Intent(DetailActivity.this, MainDetails.class);
            intent.putExtra("name", "Allergic");
            startActivity(intent);
        }

        if (v.getId() == R.id.diabetic_emg) {
            intent = new Intent(DetailActivity.this, MainDetails.class);
            intent.putExtra("name", "diabetic_emg");
            startActivity(intent);
        }

        if (v.getId() == R.id.choking_1) {
            intent = new Intent(DetailActivity.this, MainDetails.class);
            intent.putExtra("name", "choking_1");
            startActivity(intent);
        }

        if (v.getId() == R.id.nose_bleeding) {
            intent = new Intent(DetailActivity.this, MainDetails.class);
            intent.putExtra("name", "nose_bleeding");
            startActivity(intent);
        }

        if (v.getId() == R.id.head_injury) {
            intent = new Intent(DetailActivity.this, MainDetails.class);
            intent.putExtra("name", "head_injury");
            startActivity(intent);
        }

        if (v.getId() == R.id.snakebite) {
            intent = new Intent(DetailActivity.this, MainDetails.class);
            intent.putExtra("name", "Snake_Bite");
            startActivity(intent);
        }

        if (v.getId() == R.id.cpr_1) {
            intent = new Intent(DetailActivity.this, MainDetails.class);
            intent.putExtra("name", "CPR");
            startActivity(intent);
        }

        if (v.getId() == R.id.Poisoning) {

            intent = new Intent(DetailActivity.this, MainDetails.class);
            intent.putExtra("name", "Food_Poisoning");
            startActivity(intent);
        }

        if (v.getId() == R.id.Bleeding) {

            intent = new Intent(DetailActivity.this, MainDetails.class);
            intent.putExtra("name", "Bleeding");
            startActivity(intent);
        }

        if (v.getId() == R.id.sprain_1) {

            intent = new Intent(DetailActivity.this, MainDetails.class);
            intent.putExtra("name", "sprain_1");
            startActivity(intent);
        }
        if (v.getId() == R.id.Asthma) {

            intent = new Intent(DetailActivity.this, MainDetails.class);
            intent.putExtra("name", "Asthma");
            startActivity(intent);
        }

        if (v.getId() == R.id.sun_stroke) {

            intent = new Intent(DetailActivity.this, MainDetails.class);
            intent.putExtra("name", "sun_stroke");
            startActivity(intent);
        }

        if (v.getId() == R.id.bee_sting) {
            intent = new Intent(DetailActivity.this, MainDetails.class);
            intent.putExtra("name", "bee_sting");
            startActivity(intent);
        }

        if (v.getId() == R.id.migraine) {
            intent = new Intent(DetailActivity.this, MainDetails.class);
            intent.putExtra("name", "migraine");
            startActivity(intent);
        }

        if (v.getId() == R.id.electric_shock) {
            intent = new Intent(DetailActivity.this, MainDetails.class);
            intent.putExtra("name", "electric_shock");
            startActivity(intent);
        }

        if (v.getId() == R.id.fungal_infection) {
            intent = new Intent(DetailActivity.this, MainDetails.class);
            intent.putExtra("name", "Fungal_infection");
            startActivity(intent);
        }

        if (v.getId() == R.id.Food_poisoning) {
            intent = new Intent(DetailActivity.this, MainDetails.class);
            intent.putExtra("name", "Food_Poisoning");
            startActivity(intent);
        }

        if (v.getId() == R.id.hypothermia) {
            intent = new Intent(DetailActivity.this, MainDetails.class);
            intent.putExtra("name", "hypothermia");
            startActivity(intent);
        }

        if (v.getId() == R.id.panic_attack) {
            intent = new Intent(DetailActivity.this, MainDetails.class);
            intent.putExtra("name", "panic_attack");
            startActivity(intent);
        }
    }
}

