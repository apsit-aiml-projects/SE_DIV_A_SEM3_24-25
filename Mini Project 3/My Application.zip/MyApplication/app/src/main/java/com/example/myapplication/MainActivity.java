package com.example.myapplication;

import android.Manifest;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.ListView;
import android.net.Uri;
import android.widget.SearchView;


import androidx.activity.result.contract.ActivityResultContracts;


import androidx.appcompat.app.AppCompatActivity;
import androidx.core.content.ContextCompat;

public class MainActivity extends AppCompatActivity implements View.OnClickListener {

    private Intent intent;
    private Button  PredictDiseases, more_1, Call;
    private SearchView searchView;
    private ListView listView;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        searchView = findViewById(R.id.searchView);
        PredictDiseases = findViewById(R.id.predictDisease);
        more_1 = findViewById(R.id.more_1);
        Call = findViewById(R.id.btnDial);

        PredictDiseases.setOnClickListener(this);
        more_1.setOnClickListener(this);
        Call.setOnClickListener(this);
    }

    @Override
    public void onClick(View v) {
        if (v.getId() == R.id.predictDisease) {
            intent = new Intent(MainActivity.this,Predict_disease.class);
            intent.putExtra("name", "PredictDiseases");
            startActivity(intent);
        }

        if (v.getId() == R.id.more_1) {

            intent = new Intent(MainActivity.this, DetailActivity.class);
            intent.putExtra("name", "More");
            startActivity(intent);
        }
        if (v.getId() == R.id.btnDial) {
            intent = new Intent(Intent.ACTION_CALL);
            intent.setData(Uri.parse("tel:9137788314"));
            if (ContextCompat.checkSelfPermission(this, Manifest.permission.CALL_PHONE) == PackageManager.PERMISSION_GRANTED) {
                startActivity(intent);
            } else {
                // Request permission
            }
        }
    }
}