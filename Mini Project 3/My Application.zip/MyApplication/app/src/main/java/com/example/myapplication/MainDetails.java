package com.example.myapplication;

import androidx.resourceinspection.annotation.Attribute;
import androidx.appcompat.app.AppCompatActivity;
import android.os.Bundle;
import android.widget.ImageView;
import android.widget.TextView;
import android.media.MediaPlayer;

public class MainDetails extends AppCompatActivity {
    private MediaPlayer mediaPlayer;
    private ImageView imageView;
    private TextView textView;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.main_details);

        imageView = findViewById(R.id.imageViewId);
        textView = findViewById(R.id.textViewId);

        Bundle bundle = getIntent().getExtras();
        if(bundle!=null){

            String topicName = bundle.getString("name");
            showDetails(topicName);

        }

    }
    void showDetails(String topicName){
        if(topicName.equals("CPR")) {
            imageView.setImageResource(R.drawable.main_cpr);
            textView.setText(R.string.CPR);
        }
        if(topicName.equals("sprain_1")) {
            imageView.setImageResource(R.drawable.main_sprain);
            textView.setText(R.string.sprain_1);
        }
        if (topicName.equals("sun_stroke")) {
            imageView.setImageResource(R.drawable.main_sunstroke);
            textView.setText(R.string.sun_stroke);
        }
        if (topicName.equals("Burns")) {
            imageView.setImageResource(R.drawable.main_burns);
            textView.setText(R.string.Burns);
        }

        if (topicName.equals("Poisoning")) {
            imageView.setImageResource(R.drawable.main_poison);
            textView.setText(R.string.Poisoning);
        }

        if (topicName.equals("Bleeding")) {
            imageView.setImageResource(R.drawable.main_bleeding);
            textView.setText(R.string.Bleeding);
        }
        if (topicName.equals("allergic_1")) {
            imageView.setImageResource(R.drawable.main_allergy);
            textView.setText(R.string.allergic_1);
        }
        if (topicName.equals("choking_1")) {
            imageView.setImageResource(R.drawable.main_choking);
            textView.setText(R.string.choking_1);
        }
        if (topicName.equals("head_injury")) {
            imageView.setImageResource(R.drawable.main_headinjury);
            textView.setText(R.string.head_injury);
        }

        if (topicName.equals("bee_sting")) {
            imageView.setImageResource(R.drawable.main_beesting);
            textView.setText(R.string.bee_sting);
        }
        if (topicName.equals("migraine")) {
            imageView.setImageResource(R.drawable.main_migraine);
            textView.setText(R.string.migraine);
        }
        if (topicName.equals("panic_attack")) {
            imageView.setImageResource(R.drawable.main_panicattack);
            textView.setText(R.string.panic_attack);
        }
        if (topicName.equals("hypothermia")) {
            imageView.setImageResource(R.drawable.main_hypothermia);
            textView.setText(R.string.hypothermia);
        }
        if (topicName.equals("Asthma")) {
            imageView.setImageResource(R.drawable.main_asthama);
            textView.setText(R.string.Asthma);
        }
        if (topicName.equals("electric_shock")) {
            imageView.setImageResource(R.drawable.main_electricshock);
            textView.setText(R.string.electric_shock);
        }
        if (topicName.equals("Fungal_infection")) {
            imageView.setImageResource(R.drawable.main_fungal);
            textView.setText(R.string.Fungal_infection);
        }
        if (topicName.equals("diabetic_emg")) {
            imageView.setImageResource(R.drawable.main_diabeticemergency);
            textView.setText(R.string.diabetic_emg);
        }
        if (topicName.equals("nose_bleeding")) {
            imageView.setImageResource(R.drawable.main_nosebleeding);
            textView.setText(R.string.nose_bleeding);
        }
        if (topicName.equals("Snake_Bite")) {
            imageView.setImageResource(R.drawable.main_snakebite);
            textView.setText(R.string.Snake_Bite);
        }
        if (topicName.equals("Food_Poisoning")) {
            imageView.setImageResource(R.drawable.main_foodpoison);
            textView.setText(R.string.Food_Poisoning);
        }
    }
}
