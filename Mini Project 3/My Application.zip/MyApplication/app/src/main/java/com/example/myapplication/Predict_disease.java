package com.example.myapplication;

import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import java.util.HashMap;
import java.util.Map;

public class  Predict_disease extends MainActivity implements View.OnClickListener{

    private Spinner firstSymptomSpinner, secondSymptomSpinner;
    private TextView diseasePredictionTextView;

    // Symptom mappings
    private Map<String, String[]> symptomMapping = new HashMap<>();
    private Map<String, String> diseasePrediction = new HashMap<>();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.predict_disease);

        // Initialize the spinners and text view
        firstSymptomSpinner = findViewById(R.id.firstSymptomSpinner);
        secondSymptomSpinner = findViewById(R.id.secondSymptomSpinner);
        diseasePredictionTextView = findViewById(R.id.diseasePredictionTextView);

        // Populate the first symptom options
        populateFirstSymptomSpinner();
        populateDiseasePredictions();

        // Set up listener for the first spinner
        firstSymptomSpinner.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                String selectedSymptom = firstSymptomSpinner.getSelectedItem().toString();
                populateNextSymptomSpinner(selectedSymptom, secondSymptomSpinner);
            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) {
            }
        });

        // Set up listener for the second spinner
        secondSymptomSpinner.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                String firstSymptom = firstSymptomSpinner.getSelectedItem().toString();
                String secondSymptom = secondSymptomSpinner.getSelectedItem().toString();
                predictDisease(firstSymptom, secondSymptom); // Predict for two symptoms
            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) {
            }
        });
    }

    private void populateFirstSymptomSpinner() {
        String[] firstSymptoms = {
                "Headache", "Fever", "Cough", "Chest Pain", "Rash"
        };
        ArrayAdapter<String> adapter = new ArrayAdapter<>(this, android.R.layout.simple_spinner_item, firstSymptoms);
        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        firstSymptomSpinner.setAdapter(adapter);

        // Map potential next symptoms based on the first symptom
        symptomMapping.put("Headache", new String[]{"Nausea", "Dizziness", "Fatigue", "Sensitivity to Light", "Blurred Vision"});
        symptomMapping.put("Fever", new String[]{"Chills", "Sweating", "Body Ache", "Headache", "Fatigue"});
        symptomMapping.put("Cough", new String[]{"Sore Throat", "Shortness of Breath", "Chest Pain", "Wheezing", "Fever"});
        symptomMapping.put("Chest Pain", new String[]{"Shortness of Breath", "Nausea", "Sweating", "Fatigue", "Dizziness"});
        symptomMapping.put("Rash", new String[]{"Itching", "Swelling", "Fever", "Redness", "Pain"});
    }

    private void populateNextSymptomSpinner(String selectedSymptom, Spinner spinnerToPopulate) {
        String[] nextSymptoms = symptomMapping.get(selectedSymptom);
        if (nextSymptoms != null) {
            ArrayAdapter<String> adapter = new ArrayAdapter<>(this, android.R.layout.simple_spinner_item, nextSymptoms);
            adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
            spinnerToPopulate.setAdapter(adapter);
            spinnerToPopulate.setSelection(0); // Start with a blank selection
        }
    }

    private void predictDisease(String firstSymptom, String secondSymptom) {
        String key = firstSymptom + "-" + secondSymptom;
        String predictedDisease = diseasePrediction.get(key);

        if (predictedDisease != null) {
            diseasePredictionTextView.setText("Predicted Disease: \n" + predictedDisease);
        } else {
            diseasePredictionTextView.setText("No disease prediction available for this combination.");
        }
    }

    private void populateDiseasePredictions() {
        // Predict possible diseases based on combinations
        diseasePrediction.put("Headache-Nausea", "Migraine");
        diseasePrediction.put("Headache-Dizziness", "Tension Headache");
        diseasePrediction.put("Headache-Fatigue", "Chronic Fatigue Syndrome");
        diseasePrediction.put("Headache-Sensitivity to Light", "Migraine");
        diseasePrediction.put("Headache-Blurred Vision", "Migraine or Eye Strain");

        diseasePrediction.put("Fever-Chills", "Malaria");
        diseasePrediction.put("Fever-Sweating", "Dengue Fever");
        diseasePrediction.put("Fever-Body Ache", "Influenza");
        diseasePrediction.put("Fever-Headache", "Meningitis");
        diseasePrediction.put("Fever-Fatigue", "Viral Infection");

        diseasePrediction.put("Cough-Sore Throat", "Upper Respiratory Infection");
        diseasePrediction.put("Cough-Shortness of Breath", "Bronchitis");
        diseasePrediction.put("Cough-Chest Pain", "Pneumonia");
        diseasePrediction.put("Cough-Wheezing", "Asthma");
        diseasePrediction.put("Cough-Fever", "COVID-19");

        diseasePrediction.put("Chest Pain-Shortness of Breath", "Heart Attack");
        diseasePrediction.put("Chest Pain-Nausea", "Angina");
        diseasePrediction.put("Chest Pain-Sweating", "Myocardial Infarction");
        diseasePrediction.put("Chest Pain-Fatigue", "Heart Disease");
        diseasePrediction.put("Chest Pain-Dizziness", "Pulmonary Embolism");

        diseasePrediction.put("Rash-Itching", "Allergic Reaction");
        diseasePrediction.put("Rash-Swelling", "Hives");
        diseasePrediction.put("Rash-Fever", "Chickenpox");
        diseasePrediction.put("Rash-Redness", "Dermatitis");
        diseasePrediction.put("Rash-Pain", "Shingles");
    }
}



